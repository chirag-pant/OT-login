export class LoginModel{
    msg:string;
}