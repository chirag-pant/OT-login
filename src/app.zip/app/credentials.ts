export class Credentials{
    constructor(){}
        public username:String;
        public password:String;

}